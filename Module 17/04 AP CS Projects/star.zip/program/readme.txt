The Star Game (With Source) 
(C) Peter Noyes 1999

This program and the source code may be used as a resource
for game programming. Parts of the program may be used in other
programs however, the program as a whole may not be distributed.
This package may be used on the condition that the 15$ 
registration fee be payed.

-- Note
before the game can be used on the web or on a local computer the 
line containg (codebase = "file:/d:/program") must be changed
to which ever directory the program will be run from. This can be 
in the form of http://.....

Good Luck game programming!

-Peter Noyes


